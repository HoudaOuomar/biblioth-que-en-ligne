#include<stdio.h>
#include<stdlib.h>
#include<string.h>
//structure de type Date d'emprunt
typedef struct{
	int jour;
	int mois;
	int annee;
}Date;

//structure de type Livres
typedef struct{
	int id_livre;
	char Titre[15];
	char Auteur[15];
	char categorie[10];
}Livres;

//structure de type Emprunts
typedef struct{
	char nom[30];
	int id_emprunt;
	Date date_emprunt;
}Emprunts;

typedef struct{
	Emprunts emprunts;
	struct Emps* next;
}Emps;
//Head de la liste simplement chainee : Catalogue
typedef struct{
	Livres lv;
	struct Catalogue* next;
}Catalogue;

Catalogue* Ajouterlivre(Catalogue* A,int id_livre,char Titre[15],char Auteur[15],char categorie[10]);

void affichagelivre(Catalogue* A);

void rechercheParCategorie(Catalogue* A);

Emps* List_Emprunt(Emps* E);

void affichageListEmprunt(Emps* E);

Catalogue* supprimerLivre(Catalogue* A);

Catalogue* retournerLivre(Catalogue* A);

Emps* SupprimerEmprunt(Emps* E);


