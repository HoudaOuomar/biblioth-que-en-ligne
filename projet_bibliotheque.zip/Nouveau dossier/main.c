#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "bibliotheque.h"

Catalogue* A;  //Head

Catalogue* Ajouterlivre(Catalogue* A,int id_livre,char Titre[15],char Auteur[15],char categorie[10]){
	Catalogue* Temp,*p;
	Temp=(Catalogue*)malloc(sizeof(Catalogue));
	Temp->lv.id_livre=id_livre;
	strcpy(Temp->lv.Titre,Titre);
	strcpy(Temp->lv.Auteur,Auteur);
	strcpy(Temp->lv.categorie,categorie);
	p = A;
    Temp->next= NULL;
    if ( A == NULL)
    {
        A = Temp;
    }
    else {
        while ( p->next != NULL){
            p = p->next;
        }
        p->next = Temp;
    }
    return A;
}

void affichagelivre(Catalogue* A){
	Catalogue* Temp;
	Temp=A;
	while(Temp != NULL){
		printf("\n id : %d ",Temp->lv.id_livre);
		printf("\n titre : %s ",Temp->lv.Titre); 
		printf("\n Auteur : %s ",Temp->lv.Auteur);
		printf("\n Categorie : %s",Temp->lv.categorie);
		Temp=Temp->next;
		printf("\n\n ---------------------------------------------------------------------------- \n");
	}
}

void rechercheParCategorie(Catalogue* A){
	Catalogue* Temp=A;
	int trouve=0;
	char categorie[10];
	printf("\n    + Quel type de livre cherchez-vous aujourd'hui ? \n->");
	scanf("%s",categorie);

	while(Temp!=NULL){
		if(strcmp(Temp->lv.categorie,categorie)==0){
			printf("\n id : %d ",Temp->lv.id_livre);
			printf("\n titre : %s ",Temp->lv.Titre); 
			printf("\n Auteur : %s ",Temp->lv.Auteur);
			printf("\n Categorie : %s",Temp->lv.categorie);
			printf("\n\n ---------------------------------------------------------------------------- \n");
			printf("\n");
			trouve=1;	
		}
		Temp=Temp->next;
	}
	if(!trouve){
		printf("Categorie non trouve :( \n");
	}
}

Emps* List_Emprunt(Emps* E){
	Emps* Temp,*p;
	char nom[30];
	int id_emprunt, id_livre;
	Date date_emprunt;
	
	Temp=(Emps*)malloc(sizeof(Emps));
	printf("Veuillez entrer votre nom : ");
	scanf("%s",Temp->emprunts.nom);
	printf("Veuillez entrer votre id : ");
	scanf("%d",&Temp->emprunts.id_emprunt);
	printf("Veuillez entrer la date d'emprunt : \n");
	printf("- Jour : ");
	scanf("%d",&Temp->emprunts.date_emprunt.jour);
	printf("- Mois : ");
	scanf("%d",&Temp->emprunts.date_emprunt.mois);
	printf("- Annee : ");
	scanf("%d",&Temp->emprunts.date_emprunt.annee);
	printf("\n");
	p = E;
    Temp->next= NULL;
    if ( E == NULL)
    {
        E = Temp;
    }
    else {
        while ( p->next != NULL){
            p = p->next;
        }
        p->next = Temp;
    }
    return E;
}

void affichageListEmprunt(Emps* E){
	Emps* Temp;
	Temp=E;
	while(Temp != NULL){
		printf("\nnom : %s ; id : %d ; date d'emprunt : %d / %d / %d .\n",Temp->emprunts.nom,Temp->emprunts.id_emprunt,Temp->emprunts.date_emprunt.jour,Temp->emprunts.date_emprunt.mois,Temp->emprunts.date_emprunt.annee);
		Temp=Temp->next;
	}
}

Catalogue* supprimerLivre(Catalogue* A){
	Catalogue* Temp=A;
	Catalogue* p = NULL ;
	char Titre[15];
	printf("    + Selectionnez un livre qui vous intrigue et plongez-vous dans une aventure captivante ou une exploration enrichissante. Bonne lecture !\n->");
	sscanf("%s",Titre);
	while (Temp != NULL)
	{
		if (strcmp(Temp->lv.Titre,Titre)==0){
			if (p == NULL ){
				A = Temp->next;
			}
			else {
				p->next = Temp->next;
			}
			free(Temp);
			break;
		}
		p = Temp;
		Temp = Temp->next;
	}
	printf("Livre non trouve.");
	return A;
}

Catalogue* retournerLivre(Catalogue* A){
	Catalogue* Temp=A;
	int id_livre;
	char Titre[15], Auteur[15], categorie[15];
	printf("- Le Titre de livre a retourner : ");
	scanf("%s",Titre);
	printf("- Id du livre : ");
	scanf("%d",&id_livre);
	printf("- Auteur du livre : ");
	scanf("%s",Auteur);
	printf("- categorie du livre : ");
	scanf("%s",categorie);
	printf("\n");
	A=Ajouterlivre(A,id_livre,Titre,Auteur,categorie);
	printf(A);
	return A;
}

Emps* SupprimerEmprunt(Emps* E){
	Emps* Temp=E;
	Catalogue* p = NULL;
	int id_membre;
	printf(" + Veillez entrer votre id :");
	scanf("%d",&id_membre);
	while (Temp != NULL)
	{
		if (Temp->emprunts.id_emprunt == id_membre){
			if (p == NULL){
				E = Temp->next; 
			}
			else {
				p->next = Temp->next;
			}
			free(Temp);
			break;
		}
		p = Temp;
		Temp = Temp->next;
	}
	printf(E);
	printf(" Merci de retourner le livre emprunte. :)");
	return E;
}

int main(){
	Catalogue* A = NULL;
	Emps* E=NULL;
	printf("			   			   Bienvenue dans notre bibliotheque en ligne !\n\n");
	printf("									 Votre Aventure Litteraire Commence Ici...\n\n");
	A=Ajouterlivre(A,1,"Ulysse","James Joyce","Roman");
	A=Ajouterlivre(A,2,"Beloved","Toni Morrison","Roman");
	A=Ajouterlivre(A,3,"Rebecca","Daphne du Maurier","Roman");
	A=Ajouterlivre(A,4,"1984","George Orwell","Fiction");
	A=Ajouterlivre(A,5,"Dune","Frank herbert","Fiction");
	A=Ajouterlivre(A,6,"Frankenstein","Mary Shelley","Fiction");
	A=Ajouterlivre(A,7,"Matilda","Roald Dah","Histoire");
	A=Ajouterlivre(A,8,"Araby","James Joyce","Histoire");
	A=Ajouterlivre(A,9,"Cathedral","Raymond Carver","Histoire");
	A=Ajouterlivre(A,10,"Cosmos","Carl sagan","Science");
	A=Ajouterlivre(A,11,"Genius","James Gleick","Science");
	A=Ajouterlivre(A,12,"Chaos","James Gleick","Science");
	A=Ajouterlivre(A,13,"Crush","Richard Siken","Poesie");
	A=Ajouterlivre(A,14,"Devotions"," Mary Oliver","Poesie");
	A=Ajouterlivre(A,15,"Olio","Tyehimba Jess","Poesie");
	printf("	-Nous sommes ravis de vous offrir un large eventail de categories pour satisfaire toutes vos passions et curiosites. \n\n");
	
	int reponse;
	printf("    + Que preferez-vous faire aujourd'hui : emprunter un livre ou rendre un livre ?");
	printf("\n1- emprunter");
	printf("\n2- rendre");
	printf("\n->");
	scanf("%d",&reponse);
	printf("\n    + Pour profiter pleinement de notre collection et de toutes nos fonctionnalites, veuillez entrer vos informations personnelles: \n\n");
	E=List_Emprunt(E);
	if(reponse==1){
		
		printf("    + Voici un apercu des tresors litteraires et scientifiques qui vous attendent : \n\n");
		printf("1- Roman\n");
		printf("2- Fiction\n");
		printf("3- Histoire\n");
		printf("4- Science\n");
		printf("5- Poesie\n");
		rechercheParCategorie(A);	
		A = supprimerLivre(A);
		affichagelivre(A);
	}else if(reponse==2){
		printf("\n   + Veuillez entrer vos informations ci-dessous pour proceder au retour :\n");
		A=retournerLivre(A);
		E=SupprimerEmprunt(E);
	}
	
	return 0;
}
